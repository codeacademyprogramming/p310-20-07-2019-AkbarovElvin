﻿using System;

namespace TestNS
{
    public class Person
    {
        public string Firstname { get; set; }
    }

    class Developer : Person
    {
        public string FavLanguage { get; set; }
    }
}
