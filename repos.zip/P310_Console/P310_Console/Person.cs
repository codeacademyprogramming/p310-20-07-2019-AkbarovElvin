﻿namespace P310_Console
{
    
}
