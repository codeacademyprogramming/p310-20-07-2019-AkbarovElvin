﻿using System;
using TestNS;

namespace P310_Console
{
    class Program
    {
        static void Main()
        {
            #region Description of access modifiers
            //memberwise access modifier
            //private - only inside class
            //protected - inside class and children classes
            //public - all

            //class-level access modifier
            //public - all
            //internal - only inside the same assembly (.dll or .exe)
            #endregion

            Console.WriteLine(Person.indexOfPeople);

            Person person1 = new Person();
            Person person2 = new Person();
            Person person3 = new Person();
            Person person4 = new Person();

            Console.WriteLine(person1.ID);
            Console.WriteLine(person2.ID);
            Console.WriteLine(person3.ID);
            Console.WriteLine(person4.ID);
        }
    }

    class Person
    {
        private static int _numberOfPeople = 0;
        private string _id;
        public static Person[] people;
        public static int indexOfPeople = 0;

        static Person()
        {
            people = new Person[100];
        }

        public static int NumberOfPeople
        {
            get { return _numberOfPeople; }
        }

        public string ID
        {
            get { return _id; }
        }

        //Finding number of digits in a number
        //public int GetDigit()
        //{
        //    int currentNumber = _numberOfPeople;
        //    int counter = 0;
        //    while (currentNumber >= 1)
        //    {
        //        currentNumber = currentNumber / 10;
        //        counter++;
        //    }
        //    return counter;
        //}

        public Person()
        {
            _numberOfPeople++;
            _id = new string('0', 10 - _numberOfPeople.ToString().Length) + _numberOfPeople;
            people[indexOfPeople++] = this;
        }

        public Person(string firstname) : this()
        {
            Firstname = firstname;
        }

        public string Firstname { get; set; }
        
        public string ConcatName(string s)
        {
            return Firstname + s;
        }
    }

    //static class Riyaziyyat
    //{
    //    public static int Add(int a, int b) => a + b;
    //    public static int Subtract(int a, int b) => a - b;
    //    public static int Multiply(int a, int b) => a * b;
    //    public static int Divide(int a, int b) => a / b;
    //}

    
}